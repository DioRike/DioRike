$(document).ready(function () {
    /*
    // Função para carregar o conteúdo da página vinculada no elemento "conteudo"
    function carregarConteudo(url) {
        $.ajax({
            url: url,
            type: "GET",
            success: function (data) {
                $("#conteudo").html(data);
            },
            error: function () {
                $("#conteudo").html("Erro ao carregar a página.");
            }
        });
    }

    // Adicione um ouvinte de evento de clique a cada item de menu
    $(".menuServicos li a").click(function (event) {
        // Verifica se o elemento clicado não possui a classe "no-ajax"
        if (!$(this).parent().hasClass("no-ajax")) {
            event.preventDefault(); // Impede o comportamento padrão do link
            var url = $(this).attr("href");
            carregarConteudo(url); // Chama a função para carregar o conteúdo
        }
    });
    
    // Adicione um ouvinte de evento de clique ao link "teste 2" no elemento "teste"
    $("#cadastrarUsuario").click(function (event) {
        event.preventDefault(); // Impede o comportamento padrão do link
        var url = $(this).attr("href");
        carregarConteudo(url); // Chama a função para carregar o conteúdo
    });
    */
});